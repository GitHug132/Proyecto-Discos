﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ProyectoDiscos.Controllers
{
    public class GraficaController : Controller
    {
        // GET: Grafica
        public ActionResult Index()
        {
            //reuturn to view Grafica
            return View();
        }
    }
}